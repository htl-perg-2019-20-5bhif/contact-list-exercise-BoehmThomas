﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace contact_list_exercise.Controllers
{
    public class Person
    {
        [Required]
        public int id { get; set; }

        [Required]
        public string email { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }
    }


    [Route("api/contact-list")]
    [ApiController]
    public class ContactListController : ControllerBase
    {
        private static readonly List<Person> items =
            new List<Person> {
                new Person{ id = 1, email = "max.mustermann@gmx.at", firstName = "Max", lastName = "Mustermann" },
                new Person{ id = 2, email = "thomas.boehm@gmx.at", firstName = "Thomas", lastName = "Boehm" }
            };
        private List<Person> found = new List<Person> { };

        [HttpGet]
        public IActionResult GetAllPeople()
        {
            return Ok(items);
        }

        [HttpPost]
        public IActionResult AddPerson([FromBody] Person newItem)
        {
            if (newItem.id != null && newItem.email != null)
            {
                items.Add(newItem);
                return CreatedAtRoute("GetSpecificItem", new { index = items.IndexOf(newItem) }, newItem);
            }
            return BadRequest("Invalid input (e.g. required field missing or empty)");
        }

        [HttpDelete]
        [Route("{index}")]
        public IActionResult DeletePerson(int id)
        {
            if (id < 0)
            {
                return BadRequest("Invalid ID supplied");
            }
            else if (id < items.Count)
            {
                items.RemoveAt(id);
                return Ok("Successful operation");
            }
            else
            {
                return BadRequest("Person not found");
            }
        }

        [HttpGet]
        [Route("{name}", Name = "FindPersonByName")]
        public IActionResult FindPersonByName(string name)
        {

            for (int i = 0; i < items.Count; i++) {
                if(items[i].firstName.ToLower().Contains(name.ToLower()) || items[i].lastName.ToLower().Contains(name.ToLower()) ){
                    found.Add(items[i]);
                }
            }

            if (found.Count > 0)
            {
                return Ok(found);
            }

            return BadRequest("Invalid or missing name");
        }
        
    }
}
